<?php
// Boom!
require_once( JETPACK__PLUGIN_DIR . 'modules/videopress/shortcode.php' );